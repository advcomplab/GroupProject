#!/usr/bin/python
import visual
#import sys
#from PyQt4.QtGui import QPixmap, QApplication

########## Code supplied by Phil Hasnip for Year 3 Term 3 lab experiment
#  Modified by Ryan Pound
#  Produces 3D image of the unit cell of supplied cell file, colour coding
#  and scaling atoms. Code for auto capturing print screen commented out
#  see README for more details

elementName = [ "Mg", "Ca", "O" ]
 
class atom:
    def __init__(self,name,v,atom_radius):
        self.name = name
        self.position = v
        #set the colour of the atoms dependant on their element
        if name == "Mg":
            self.pic = visual.sphere(pos=self.position,radius=atom_radius,color=visual.color.orange)
        elif name == "Ca":
            self.pic = visual.sphere(pos=self.position,radius=atom_radius,color=visual.color.red)
        elif name == "O":
            self.pic = visual.sphere(pos=self.position,radius=atom_radius,color=visual.color.blue)
        else:
            self.pic = visual.sphere(pos=self.position,radius=atom_radius,color=visual.color.white)


# Create the empty list myAtoms
myAtoms = []

# Create the empty list fracPos
fracPos = []

lattice = []

# Get the fractional coordinates and lattice from the CASTEP input cell file
cell_file = raw_input()
with open(cell_file, "r") as inputFile:

    inPosBlock = False
    inLatticeBlock = False

    for line in inputFile:
        if inPosBlock:
            if line.lower() == "%endblock positions_frac\n":
                inPosBlock = False
            else:
                name, x, y, z= line.split()
                fracPos.append([name,x,y,z])

        if inLatticeBlock:
            if line.lower() == "%endblock lattice_cart\n":
                inLatticeBlock = False
            else:
                x,y,z = line.split()
                lattice.append(visual.vector(float(x),float(y),float(z)))

        if line.lower() == "%block lattice_cart\n":
            inLatticeBlock = True

        if line.lower() == "%block positions_frac\n":
            inPosBlock = True

inputFile.close()
atom_display = visual.display(title=cell_file)

# Draw the lattice vectors
for a in lattice:
    visual.arrow(pos=visual.vector(0.0,0.0,0.0),axis=a,shaftwidth=0.01)
# ensure that the atoms will always match the size of the cell
atom_radius = 4.0 / len(fracPos)

for a in fracPos:
    absPos = visual.vector(0.0,0.0,0.0)
    # Convert to absolute, Cartesian co-ordinates
    for i in [ 0, 1, 2 ]:
        absPos = absPos + float(a[i+1])*lattice[i]
    # Add to displayed atoms
    myAtoms.append(atom(a[0],absPos,atom_radius))
    
########## code to show the atom bonds
#  - this has been removed because the size of the cells results in it not 
#    clearly showing the unit cell. Can be erqorked in the future
#bonds = []
#for a in myAtoms:
#    for b in myAtoms:
#        if abs(a.position - b.position)<5.0:
#            bonds.append(visual.cylinder(pos=a.position,axis=(b.position-a.position),radius=0.01,color=visual.color.white))

########## 
print "Image of cell described by ", cell_file
print "Key: Mg - orange, Ca - red, O - blue"

########## Screen shot code has been shown to work but hasn't worked in this for some reason
#app = QApplication(sys.argv)
#QPixmap.grabWindow(QApplication.desktop().winId()).save('test.png', 'png')
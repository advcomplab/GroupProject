#!/bin/bash

for count in 1 2 3 4 5 6 7 8 9 10 11 12 13

do
   echo 'MgO'${count}'.cell' | python Visualize_Cell.py

done
